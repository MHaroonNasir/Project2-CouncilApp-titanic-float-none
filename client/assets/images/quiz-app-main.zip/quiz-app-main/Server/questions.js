const questions = require("./questions.json");
module.exports = questions;
