/**
 * @jest-environment jsdom
 */

const revision = require("./revisionList");
